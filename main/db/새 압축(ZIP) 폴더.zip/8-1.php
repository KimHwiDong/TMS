<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
</head>
<body>
  <form action="8-2.php">

  	  <P>기기번호를 입력해주세요 </P>
      <input type = "text" name ="machine_num">

      <p>비밀번호를 입력해주세요.</p>
      <input type="text" name="password">

      <input type="submit" value="기기 로그인">
  </form>
</body>
</html>