<?php
date_default_timezone_set('Asia/Seoul');
	error_reporting(E_ALL);
    ini_set("display_errors", 1);
	$servername = "localhost";
	$username = "root";
	$password = "gnlehdvskim1!";
	$dbname = "konanservice";
	$conn = new mysqli($servername, $username, $password, $dbname);

	if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
	} else if($conn){
		echo "DB Connect";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php


$password = $_GET["password"];
$machine_num = $_GET["machine_num"];
$m_num  = "SELECT machine_num from measure_machine where machine_num = '".$machine_num."';";
$result_set1 = mysqli_query($conn,$m_num);
$row1=mysqli_fetch_array($result_set1);
echo $row1['machine_num'];


    if($password == "1111" && strcmp($machine_num, $m_num) ){
        echo "주인님 환영합니다1!";
        echo $_GET["machine_num"];
        echo $_GET["password"];
    } else {
        echo "뉘신지?";
       
    }

?>
	
	<p> lali </p>
</body>
</html>